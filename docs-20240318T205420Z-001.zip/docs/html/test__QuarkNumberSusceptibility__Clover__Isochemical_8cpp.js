var test__QuarkNumberSusceptibility__Clover__Isochemical_8cpp =
[
    [ "quark_num_suscept", "test__QuarkNumberSusceptibility__Clover__Isochemical_8cpp.html#a86337a4940bae37acaafd83a5cda1044", null ],
    [ "test_name", "test__QuarkNumberSusceptibility__Clover__Isochemical_8cpp.html#aef118edebf0191a68a1d011a2bbd0eef", null ]
];