var test__HMC__Staggered__Nf4__eo_8cpp =
[
    [ "update_Nf4_eo", "test__HMC__Staggered__Nf4__eo_8cpp.html#a3d22bd83f1e14b44ffd15d07996aa99f", null ],
    [ "test_name", "test__HMC__Staggered__Nf4__eo_8cpp.html#acb65993c112c627335442413410b10b0", null ]
];