var test__Spectrum__4ptFunction_8cpp =
[
    [ "hadron_4ptFunction", "test__Spectrum__4ptFunction_8cpp.html#a1c0317d649f139df0e2014bdd71f0b70", null ],
    [ "hadron_4ptFunction_Clover", "test__Spectrum__4ptFunction_8cpp.html#a745ac8a733c953b0d35bed7f20de95de", null ]
];