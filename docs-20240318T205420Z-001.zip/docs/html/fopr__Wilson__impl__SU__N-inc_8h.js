var fopr__Wilson__impl__SU__N_inc_8h =
[
    [ "ID1", "fopr__Wilson__impl__SU__N-inc_8h.html#ae9e0e1185f86f6ae7aa50b109fc423cc", null ],
    [ "ID2", "fopr__Wilson__impl__SU__N-inc_8h.html#abbb71547df5cc7788a2312ede1c4f9f9", null ],
    [ "ID3", "fopr__Wilson__impl__SU__N-inc_8h.html#a74e834603283d49c89509493d77dc85d", null ],
    [ "ID4", "fopr__Wilson__impl__SU__N-inc_8h.html#a22888eb5d90caae4a6c80f67f717bcff", null ],
    [ "NC", "fopr__Wilson__impl__SU__N-inc_8h.html#a1fa2460e32327ade49189c95740bc1b5", null ],
    [ "NCOL", "fopr__Wilson__impl__SU__N-inc_8h.html#a1133f0acccd213ff23c60599bfa1a0b2", null ],
    [ "ND", "fopr__Wilson__impl__SU__N-inc_8h.html#a68d169e5b90cf721678bc7ab0f964a99", null ],
    [ "NVC", "fopr__Wilson__impl__SU__N-inc_8h.html#a0908eb1a769dd99966d66e85ee08da91", null ]
];