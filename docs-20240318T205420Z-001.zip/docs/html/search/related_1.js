var searchData=
[
  ['communicator_5fimpl_0',['Communicator_impl',['../classChannel__communicator.html#aba4cedb67a9094744b5dcf7295751a6f',1,'Channel_communicator']]],
  ['copy_1',['copy',['../classField.html#a4c4ec7aa28fe9086b04a8c1ebbf762c0',1,'Field::copy()'],['../classField.html#ac330031341565a662188ccf37e6946a7',1,'Field::copy()']]]
];
