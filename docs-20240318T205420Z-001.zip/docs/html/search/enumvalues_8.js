var searchData=
[
  ['lexical_0',['LEXICAL',['../classAPrecond__Mixedprec.html#a82174ba75f784a148513725af5cebc02a8748e9e4a6db01b96e13df26bcfdbfa3',1,'APrecond_Mixedprec']]]
];
