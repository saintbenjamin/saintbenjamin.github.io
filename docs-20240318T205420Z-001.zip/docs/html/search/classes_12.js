var searchData=
[
  ['unique_5fptr_0',['unique_ptr',['../classBridge_1_1unique__ptr.html',1,'Bridge']]],
  ['unique_5fptr_3c_20t_5b_5d_3e_1',['unique_ptr&lt; T[]&gt;',['../classBridge_1_1unique__ptr_3_01T_0f_0e_4.html',1,'Bridge']]],
  ['usimd_5ft_2',['Usimd_t',['../structUsimd__t.html',1,'']]]
];
