var searchData=
[
  ['backward_0',['Backward',['../bridge__defs_8h.html#a1dba4769c15fc784242648e7f0befff2a67e19347f85332c3bbfd61266cecbe4e',1,'bridge_defs.h']]]
];
