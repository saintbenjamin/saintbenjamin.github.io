var searchData=
[
  ['bridge_5fversion_0',['BRIDGE_VERSION',['../configure_8h.html#a932cc75f239c5de6e47bd5d4c14fa36e',1,'configure.h']]]
];
