var searchData=
[
  ['sigma12_0',['SIGMA12',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3a092e4dcd11214e6c7735ab36eadbc85e',1,'GammaMatrixSet']]],
  ['sigma23_1',['SIGMA23',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3acfd3bdab7312742c7ec1c8b01c251a6e',1,'GammaMatrixSet']]],
  ['sigma31_2',['SIGMA31',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3a5bbaeae0e70aaa6c06c3c2b0f5eea99e',1,'GammaMatrixSet']]],
  ['sigma41_3',['SIGMA41',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3a392a8aec55b221149db2fab3d0bdd131',1,'GammaMatrixSet']]],
  ['sigma42_4',['SIGMA42',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3ad6f504910d5697fad6587650ad81990d',1,'GammaMatrixSet']]],
  ['sigma43_5',['SIGMA43',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3a96f09d8e36a6a581aba689fd124db30a',1,'GammaMatrixSet']]],
  ['simd_6',['SIMD',['../alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391aec3e9727bbc5c1073d8dc6fea807783a',1,'alt_impl.h']]],
  ['simd2_7',['SIMD2',['../alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a90f2545bda75c5d31f1f65b3d8b7f275',1,'alt_impl.h']]]
];
