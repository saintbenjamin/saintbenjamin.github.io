var searchData=
[
  ['tdir_0',['TDIR',['../bridge__defs_8h.html#a224b9163917ac32fc95a60d8c1eec3aaaa568e34ea111fd8c6860ceaa57423432',1,'bridge_defs.h']]]
];
