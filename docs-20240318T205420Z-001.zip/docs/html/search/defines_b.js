var searchData=
[
  ['use_5fsap_5ffor_5fsmoother_0',['USE_SAP_FOR_SMOOTHER',['../asolver__MG_8cpp.html#a644495238055de228ac70fcac659332c',1,'USE_SAP_FOR_SMOOTHER():&#160;asolver_MG.cpp'],['../asolver__MG__double_8cpp.html#a644495238055de228ac70fcac659332c',1,'USE_SAP_FOR_SMOOTHER():&#160;asolver_MG_double.cpp']]]
];
