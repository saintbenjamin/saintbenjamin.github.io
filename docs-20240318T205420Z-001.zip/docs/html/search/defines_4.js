var searchData=
[
  ['deprecated_0',['DEPRECATED',['../configure_8h.html#ac1e8a42306d8e67cb94ca31c3956ee78',1,'configure.h']]]
];
