var searchData=
[
  ['unique_5fpointer_2eh_0',['unique_pointer.h',['../unique__pointer_8h.html',1,'']]]
];
