var searchData=
[
  ['omega_0',['omega',['../structASolver__BiCGStab__Cmplx_1_1coeff__t.html#a37b8b682885854db02bc9b9ee2ab3765',1,'ASolver_BiCGStab_Cmplx::coeff_t']]],
  ['os_5f_1',['os_',['../classBridge_1_1BridgeIO.html#a55c07cdedd54628dcc64a8bd7f0ca933',1,'Bridge::BridgeIO']]]
];
