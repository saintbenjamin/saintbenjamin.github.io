var searchData=
[
  ['log_0',['LOG',['../bridge__defs_8h.html#a159ca84d25a5487d8e81e4438725df19',1,'bridge_defs.h']]]
];
