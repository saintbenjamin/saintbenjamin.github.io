var searchData=
[
  ['direction_0',['Direction',['../bridge__defs_8h.html#a224b9163917ac32fc95a60d8c1eec3aa',1,'bridge_defs.h']]]
];
