var searchData=
[
  ['zdir_0',['ZDIR',['../bridge__defs_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa9c67f9a8ef28f52a4e7016ab01bad677',1,'bridge_defs.h']]],
  ['zero_1',['ZERO',['../classASolver.html#aab295952c5891fe024ac3a23b06cee2ba948b39949c7a79ceea1429187138db2d',1,'ASolver']]]
];
