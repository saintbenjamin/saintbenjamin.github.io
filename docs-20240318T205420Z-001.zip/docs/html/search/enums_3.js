var searchData=
[
  ['impl_0',['Impl',['../alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391',1,'alt_impl.h']]],
  ['initialguess_1',['InitialGuess',['../classASolver.html#aab295952c5891fe024ac3a23b06cee2b',1,'ASolver']]]
];
