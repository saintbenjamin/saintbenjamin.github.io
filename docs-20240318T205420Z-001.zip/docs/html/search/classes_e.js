var searchData=
[
  ['quarknumbersusceptibility_5fwilson_0',['QuarkNumberSusceptibility_Wilson',['../classQuarkNumberSusceptibility__Wilson.html',1,'']]]
];
