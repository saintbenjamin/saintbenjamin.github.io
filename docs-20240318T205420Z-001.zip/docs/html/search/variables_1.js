var searchData=
[
  ['alpha_0',['alpha',['../structASolver__BiCGStab__Cmplx_1_1coeff__t.html#a5301567d6c5f3f5b886745aa90e74b05',1,'ASolver_BiCGStab_Cmplx::coeff_t::alpha()'],['../structASolver__FBiCGStab_1_1coeff__t.html#a879a5a16c2564d4f3bc6692988e5b79d',1,'ASolver_FBiCGStab::coeff_t::alpha()']]]
];
