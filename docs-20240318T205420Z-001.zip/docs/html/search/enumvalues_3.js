var searchData=
[
  ['default_5fformat_5fprecision_0',['default_format_precision',['../dataIO__Text_8h.html#a06fc87d81c62e9abb8790b6e5713c55bacb2769283e3b08d68ab70d6c510f98eb',1,'dataIO_Text.h']]],
  ['detailed_1',['DETAILED',['../namespaceBridge.html#a5cc93dfee93b04ed3a7391cd0d9320bfaa68b88cda9d5de1d35fa272ee2206c26',1,'Bridge']]]
];
