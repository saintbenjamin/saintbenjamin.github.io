var searchData=
[
  ['_5fptr_0',['_ptr',['../classBridge_1_1unique__ptr.html#a06f7f5f71e2a422b280305df97f01636',1,'Bridge::unique_ptr::_ptr()'],['../classBridge_1_1unique__ptr_3_01T_0f_0e_4.html#ae3de2eec9ec44f32c021512dcf6fd3b2',1,'Bridge::unique_ptr&lt; T[]&gt;::_ptr()']]]
];
