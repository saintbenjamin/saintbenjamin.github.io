var searchData=
[
  ['afield_5fhas_5fdotc_5fand_5fnorm2_0',['AFIELD_HAS_DOTC_AND_NORM2',['../afield-inc_8h.html#a3055bcc0f624c7a35f00a1e638dcc625',1,'afield-inc.h']]],
  ['afopr_5fclover_5fcoarse_5ftimer_1',['AFOPR_CLOVER_COARSE_TIMER',['../afopr__Clover__coarse-tmpl_8h.html#aa8278e264e9aded921c45e57ca0e7dcc',1,'afopr_Clover_coarse-tmpl.h']]]
];
