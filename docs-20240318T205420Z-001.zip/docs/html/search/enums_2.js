var searchData=
[
  ['gmspecies_0',['GMspecies',['../classGammaMatrixSet.html#af90016a02727e41b53916b466e8eb7f3',1,'GammaMatrixSet']]]
];
