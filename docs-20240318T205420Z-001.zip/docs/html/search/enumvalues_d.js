var searchData=
[
  ['qxs_0',['QXS',['../alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391aa9a84ec502f3fb0c968bddf54b390003',1,'alt_impl.h']]]
];
