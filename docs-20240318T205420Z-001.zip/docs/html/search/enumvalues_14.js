var searchData=
[
  ['xdir_0',['XDIR',['../bridge__defs_8h.html#a224b9163917ac32fc95a60d8c1eec3aaa1d73dc463abcb5f0ec3167f3107aa2ea',1,'bridge_defs.h']]]
];
