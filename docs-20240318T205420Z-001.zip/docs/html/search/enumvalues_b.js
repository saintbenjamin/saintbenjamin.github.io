var searchData=
[
  ['openacc_0',['OPENACC',['../alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a6ee90253bddf7d833c52893e037a869f',1,'alt_impl.h']]]
];
