var searchData=
[
  ['uint_5ft_0',['uint_t',['../inline__General_2vsimd__double-inc_8h.html#a12a1e9b3ce141648783a82445d02b58d',1,'uint_t():&#160;vsimd_double-inc.h'],['../inline__General_2vsimd__float-inc_8h.html#a12a1e9b3ce141648783a82445d02b58d',1,'uint_t():&#160;vsimd_float-inc.h']]],
  ['unit_5fvec_1',['unit_vec',['../classWilsonLoop.html#ae70b07b89e6bd361d5c9691b6938a940',1,'WilsonLoop']]],
  ['unspecified_5fbool_5ftype_2',['unspecified_bool_type',['../classBridge_1_1unique__ptr.html#ade8cc472bb70cb8fafcd4b3dd04e22a7',1,'Bridge::unique_ptr']]]
];
