var dir_45dccc08087732e89a875b2e8b821018 =
[
    [ "test_IO_Data_Text.cpp", "test__IO__Data__Text_8cpp.html", "test__IO__Data__Text_8cpp" ],
    [ "test_IO_GaugeConfig.cpp", "test__IO__GaugeConfig_8cpp.html", "test__IO__GaugeConfig_8cpp" ]
];