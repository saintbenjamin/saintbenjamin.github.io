var dir_c8d7053bd29294d04afff50f02e79262 =
[
    [ "channel.cpp", "MPI_2channel_8cpp.html", null ],
    [ "channel.h", "MPI_2channel_8h.html", "MPI_2channel_8h" ],
    [ "communicator.cpp", "MPI_2communicator_8cpp.html", null ],
    [ "communicator_mpi.cpp", "MPI_2communicator__mpi_8cpp.html", "MPI_2communicator__mpi_8cpp" ],
    [ "communicator_mpi.h", "MPI_2communicator__mpi_8h.html", "MPI_2communicator__mpi_8h" ],
    [ "layout.cpp", "MPI_2layout_8cpp.html", null ],
    [ "layout.h", "MPI_2layout_8h.html", "MPI_2layout_8h" ],
    [ "physical_map.cpp", "MPI_2physical__map_8cpp.html", "MPI_2physical__map_8cpp" ]
];