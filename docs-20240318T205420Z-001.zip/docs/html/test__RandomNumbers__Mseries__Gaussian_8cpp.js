var test__RandomNumbers__Mseries__Gaussian_8cpp =
[
    [ "gaussian", "test__RandomNumbers__Mseries__Gaussian_8cpp.html#a2890b993f072265278c6110ff7c7a4f2", null ],
    [ "test_name", "test__RandomNumbers__Mseries__Gaussian_8cpp.html#a5ce9deb3b7cbf4858607137e122cf6e4", null ]
];