var gaugeFixing__Landau_8h =
[
    [ "GaugeFixing_Landau", "classGaugeFixing__Landau.html", "classGaugeFixing__Landau" ],
    [ "CHECK_NC_3", "gaugeFixing__Landau_8h.html#ae555c02b9516e97a482a49a07ce28ef7", null ]
];