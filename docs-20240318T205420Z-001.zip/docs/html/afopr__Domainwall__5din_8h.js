var afopr__Domainwall__5din_8h =
[
    [ "AFopr_Domainwall_5din< AFIELD >", "classAFopr__Domainwall__5din.html", "classAFopr__Domainwall__5din" ],
    [ "AFopr_Domainwall_General_5din", "afopr__Domainwall__5din_8h.html#a921d31b95a3df4700f3c281a73523880", null ]
];