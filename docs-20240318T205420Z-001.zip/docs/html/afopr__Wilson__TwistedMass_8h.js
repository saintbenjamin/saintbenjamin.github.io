var afopr__Wilson__TwistedMass_8h =
[
    [ "AFopr_Wilson_TwistedMass< AFIELD >", "classAFopr__Wilson__TwistedMass.html", "classAFopr__Wilson__TwistedMass" ]
];