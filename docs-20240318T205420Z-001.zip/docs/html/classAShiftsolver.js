var classAShiftsolver =
[
    [ "AShiftsolver", "classAShiftsolver.html#ae862594baa5a839c3ea8181f181a9105", null ],
    [ "~AShiftsolver", "classAShiftsolver.html#a63e29b407bca5caaa578c3afa20adb4f", null ],
    [ "AShiftsolver", "classAShiftsolver.html#a3a6b2810a12abf5df028cefa88b434b6", null ],
    [ "flop_count", "classAShiftsolver.html#ac9c67d4a79cb52b23b31e01f8b64e58c", null ],
    [ "get_parameters", "classAShiftsolver.html#a6f012de8c70f70dffe43d9ad912dbc5d", null ],
    [ "operator=", "classAShiftsolver.html#adb4aa8956ff8b78ea350a355de8fa356", null ],
    [ "set_parameters", "classAShiftsolver.html#a1c5ed9d7c0d4e56576228338a98bcc2a", null ],
    [ "solve", "classAShiftsolver.html#a8ec9c2ff660c977047f764c49ac8909f", null ]
];