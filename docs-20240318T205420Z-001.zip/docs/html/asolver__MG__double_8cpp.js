var asolver__MG__double_8cpp =
[
    [ "USE_SAP_FOR_SMOOTHER", "asolver__MG__double_8cpp.html#a644495238055de228ac70fcac659332c", null ],
    [ "AField_d", "asolver__MG__double_8cpp.html#acb83ad128341a401a0edee5867f3228b", null ],
    [ "CoarseSolver_t", "asolver__MG__double_8cpp.html#a05fedffe0adefcd0265bd69621837866", null ],
    [ "FoprCoarse_t", "asolver__MG__double_8cpp.html#a959f57a6e92f4bcc0215042c66562c29", null ],
    [ "FoprD_t", "asolver__MG__double_8cpp.html#afd58ac0169d7d0e6c25fa60ea8f49d30", null ],
    [ "FoprF_t", "asolver__MG__double_8cpp.html#a16478c8ccf700ce756c79537a7407e85", null ],
    [ "MultiGrid_t", "asolver__MG__double_8cpp.html#a9398a6c25d51a9f632550dd6d97d5074", null ],
    [ "OuterSolver_t", "asolver__MG__double_8cpp.html#a63ceb2e97f7238f5fb394086fc28e0df", null ],
    [ "Smoother_t", "asolver__MG__double_8cpp.html#acae98c4e56421cf09aeb12d5e210e046", null ]
];