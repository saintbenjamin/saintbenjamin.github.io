var eigensolver_8cpp =
[
    [ "AFIELD", "eigensolver_8cpp.html#a6ed2020c395189d5010363eaf749fc91", null ],
    [ "AFOPR", "eigensolver_8cpp.html#aa61421c3563658930fc0c5fd46ece63b", null ]
];