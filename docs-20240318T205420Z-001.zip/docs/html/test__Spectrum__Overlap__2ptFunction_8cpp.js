var test__Spectrum__Overlap__2ptFunction_8cpp =
[
    [ "hadron_2ptFunction", "test__Spectrum__Overlap__2ptFunction_8cpp.html#a49af5df8d1c083add5d3d1452b68a0b0", null ],
    [ "test_name", "test__Spectrum__Overlap__2ptFunction_8cpp.html#a12b67bac3e3cd147ad3a9b6f38f6b7fb", null ]
];