var inline__General_2define__params__SU3_8h =
[
    [ "NC", "inline__General_2define__params__SU3_8h.html#a1fa2460e32327ade49189c95740bc1b5", null ],
    [ "NCD", "inline__General_2define__params__SU3_8h.html#aa71db319a9b89088876191a0d38153ee", null ],
    [ "ND", "inline__General_2define__params__SU3_8h.html#a68d169e5b90cf721678bc7ab0f964a99", null ],
    [ "ND2", "inline__General_2define__params__SU3_8h.html#ac56263169eeec7eceb95ef02dd06425f", null ],
    [ "NDF", "inline__General_2define__params__SU3_8h.html#a8d5a7fa9b1c30303857addd127b92269", null ],
    [ "NDF2", "inline__General_2define__params__SU3_8h.html#ab9872f159e7e5b40246b4ba916979775", null ],
    [ "NVC", "inline__General_2define__params__SU3_8h.html#a0908eb1a769dd99966d66e85ee08da91", null ],
    [ "NVCD", "inline__General_2define__params__SU3_8h.html#a2474f769b4155bbe8225050cd32d687a", null ]
];