var test__Spectrum__Nonrelativistic__2ptFunction_8cpp =
[
    [ "heavy_heavy_2ptFunction", "test__Spectrum__Nonrelativistic__2ptFunction_8cpp.html#a89de5220f274b3be3e4038bc5aba1db0", null ],
    [ "test_name", "test__Spectrum__Nonrelativistic__2ptFunction_8cpp.html#a2a9e42e0c2fb0d2aeed3181f5179c5a9", null ]
];