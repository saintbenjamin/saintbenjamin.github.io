var action__F__Ratio__lex__alt_8h =
[
    [ "Action_F_Ratio_lex_alt< AFIELD >", "classAction__F__Ratio__lex__alt.html", "classAction__F__Ratio__lex__alt" ]
];