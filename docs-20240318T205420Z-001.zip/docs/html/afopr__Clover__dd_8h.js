var afopr__Clover__dd_8h =
[
    [ "AFopr_Clover_dd< AFIELD >", "classAFopr__Clover__dd.html", "classAFopr__Clover__dd" ]
];