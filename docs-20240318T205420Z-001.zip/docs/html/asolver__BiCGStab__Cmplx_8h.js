var asolver__BiCGStab__Cmplx_8h =
[
    [ "ASolver_BiCGStab_Cmplx< AFIELD >", "classASolver__BiCGStab__Cmplx.html", "classASolver__BiCGStab__Cmplx" ],
    [ "ASolver_BiCGStab_Cmplx< AFIELD >::coeff_t", "structASolver__BiCGStab__Cmplx_1_1coeff__t.html", "structASolver__BiCGStab__Cmplx_1_1coeff__t" ]
];