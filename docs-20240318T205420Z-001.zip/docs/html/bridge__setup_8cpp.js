var bridge__setup_8cpp =
[
    [ "bridge_finalize", "bridge__setup_8cpp.html#aaa7cd35b249aec19ca61f649621110e9", null ],
    [ "bridge_initialize", "bridge__setup_8cpp.html#a31fec7e2cc8eb462f4bd304395122422", null ],
    [ "bridge_initialize", "bridge__setup_8cpp.html#ad2cfc9be4f7a7ac9ffb257f451b873fd", null ],
    [ "bridge_initialize", "bridge__setup_8cpp.html#a35236c9bf2299b61c88e300c270129ee", null ],
    [ "bridge_setup", "bridge__setup_8cpp.html#a28c331ac36e549f399f6b89b5a8cd350", null ],
    [ "bridge_setup", "bridge__setup_8cpp.html#a967a2eeac450d3474f4c945221112095", null ]
];