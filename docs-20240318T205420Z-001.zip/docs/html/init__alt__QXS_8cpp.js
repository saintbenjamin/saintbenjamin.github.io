var init__alt__QXS_8cpp =
[
    [ "fin_alt_QXS", "init__alt__QXS_8cpp.html#ab02b05726c6e0207089280e846708e74", null ],
    [ "init_alt_QXS", "init__alt__QXS_8cpp.html#a34a23b7bef294c5aebed763d167d6a4e", null ]
];