var field__G__imp__SU3_inc_8h =
[
    [ "NC", "field__G__imp__SU3-inc_8h.html#a1fa2460e32327ade49189c95740bc1b5", null ],
    [ "NCOL", "field__G__imp__SU3-inc_8h.html#a1133f0acccd213ff23c60599bfa1a0b2", null ]
];