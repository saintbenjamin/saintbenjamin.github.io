var unique__pointer_8h =
[
    [ "Bridge::unique_ptr< T >", "classBridge_1_1unique__ptr.html", "classBridge_1_1unique__ptr" ],
    [ "Bridge::unique_ptr< T[]>", "classBridge_1_1unique__ptr_3_01T_0f_0e_4.html", "classBridge_1_1unique__ptr_3_01T_0f_0e_4" ],
    [ "_assert", "unique__pointer_8h.html#a75c0981dfa33921f5edc9f2aa0c5370e", null ]
];