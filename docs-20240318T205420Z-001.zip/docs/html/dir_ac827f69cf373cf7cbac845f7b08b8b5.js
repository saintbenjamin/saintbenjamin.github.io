var dir_ac827f69cf373cf7cbac845f7b08b8b5 =
[
    [ "aprecond.cpp", "aprecond_8cpp.html", null ],
    [ "aprecond_MG.cpp", "aprecond__MG_8cpp.html", null ],
    [ "aprecond_Mixedprec.cpp", "aprecond__Mixedprec_8cpp.html", null ],
    [ "asolver.cpp", "asolver_8cpp.html", null ],
    [ "asolver_BiCGStab.cpp", "asolver__BiCGStab_8cpp.html", null ],
    [ "asolver_BiCGStab_Cmplx.cpp", "asolver__BiCGStab__Cmplx_8cpp.html", null ],
    [ "asolver_BiCGStab_Precond.cpp", "asolver__BiCGStab__Precond_8cpp.html", null ],
    [ "asolver_CG.cpp", "asolver__CG_8cpp.html", null ],
    [ "asolver_CGNR.cpp", "asolver__CGNR_8cpp.html", null ],
    [ "asolver_FBiCGStab.cpp", "asolver__FBiCGStab_8cpp.html", null ],
    [ "asolver_MG.cpp", "asolver__MG_8cpp.html", "asolver__MG_8cpp" ],
    [ "asolver_MG_double.cpp", "asolver__MG__double_8cpp.html", "asolver__MG__double_8cpp" ],
    [ "asolver_Richardson.cpp", "asolver__Richardson_8cpp.html", null ],
    [ "asolver_SAP.cpp", "asolver__SAP_8cpp.html", null ],
    [ "asolver_SAP_MINRES_double.cpp", "asolver__SAP__MINRES__double_8cpp.html", "asolver__SAP__MINRES__double_8cpp" ],
    [ "asolver_SAP_MINRES_float.cpp", "asolver__SAP__MINRES__float_8cpp.html", "asolver__SAP__MINRES__float_8cpp" ],
    [ "asolver_SAP_QWS.cpp", "asolver__SAP__QWS_8cpp.html", null ],
    [ "asolver_SAP_QWS.h", "asolver__SAP__QWS_8h.html", "asolver__SAP__QWS_8h" ],
    [ "MultiGrid.cpp", "MultiGrid_8cpp.html", "MultiGrid_8cpp" ],
    [ "MultiGrid_Clover_double.cpp", "MultiGrid__Clover__double_8cpp.html", "MultiGrid__Clover__double_8cpp" ],
    [ "MultiGrid_Clover_float.cpp", "MultiGrid__Clover__float_8cpp.html", "MultiGrid__Clover__float_8cpp" ]
];