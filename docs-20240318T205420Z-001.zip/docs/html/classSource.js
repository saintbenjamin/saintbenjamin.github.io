var classSource =
[
    [ "Source", "classSource.html#a660c0a4b8b8f8402568bef86f2cb2fbb", null ],
    [ "~Source", "classSource.html#ad78297e3d514281fedd1d727e80bf158", null ],
    [ "Source", "classSource.html#a203eb97ecde008086f44031c5e32817b", null ],
    [ "get_parameters", "classSource.html#a945692aa2e2191cdf990fdfad9860006", null ],
    [ "operator=", "classSource.html#a8a5544fd67cdf619fe2dd977745a1314", null ],
    [ "set", "classSource.html#a19ed1e03eac28e309ffa87061603ea28", null ],
    [ "set", "classSource.html#af102a518768a49426b2bd83cad7ad4f6", null ],
    [ "set_all_color", "classSource.html#a779401e99180f1f7657ce042a347d26c", null ],
    [ "set_all_color_spin", "classSource.html#a5e4f99efb9990b59ed0a7d4c17fa8f89", null ],
    [ "set_parameters", "classSource.html#aab48dbd5350fa5fb256af572f1460fbf", null ]
];