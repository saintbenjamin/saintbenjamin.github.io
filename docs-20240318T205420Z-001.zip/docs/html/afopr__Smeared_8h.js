var afopr__Smeared_8h =
[
    [ "AFopr_Smeared< AFIELD >", "classAFopr__Smeared.html", "classAFopr__Smeared" ]
];