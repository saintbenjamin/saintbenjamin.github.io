var asolver__MG__double_8h =
[
    [ "ASolver_MG_double< AFIELD >", "classASolver__MG__double.html", "classASolver__MG__double" ]
];