var asolver__CGNR_8h =
[
    [ "ASolver_CGNR< AFIELD >", "classASolver__CGNR.html", "classASolver__CGNR" ]
];