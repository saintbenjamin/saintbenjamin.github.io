var test__RandomNumbers__Mseries__Uniform_8cpp =
[
    [ "uniform_calc_pi", "test__RandomNumbers__Mseries__Uniform_8cpp.html#a81dcdd5978e22bcc4f0a505423b10397", null ]
];