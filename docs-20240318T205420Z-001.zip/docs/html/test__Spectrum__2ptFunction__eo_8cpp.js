var test__Spectrum__2ptFunction__eo_8cpp =
[
    [ "hadron_2ptFunction_eo", "test__Spectrum__2ptFunction__eo_8cpp.html#a3fd279c65314817773d2616c604db95c", null ],
    [ "hadron_2ptFunction_eo_Clover", "test__Spectrum__2ptFunction__eo_8cpp.html#a855a77d4c81b10c12cc77dff8843475d", null ],
    [ "hadron_2ptFunction_eo_Wilson", "test__Spectrum__2ptFunction__eo_8cpp.html#a4b79fba7256bec8bbf50cd653626a3c8", null ]
];