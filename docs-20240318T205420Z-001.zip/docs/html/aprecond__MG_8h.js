var aprecond__MG_8h =
[
    [ "APrecond_MG< AFIELD, AFIELD2 >", "classAPrecond__MG.html", "classAPrecond__MG" ]
];