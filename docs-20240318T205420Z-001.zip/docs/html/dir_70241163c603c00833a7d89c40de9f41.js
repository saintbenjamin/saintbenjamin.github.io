var dir_70241163c603c00833a7d89c40de9f41 =
[
    [ "Fermion", "dir_96c4b607d72bc8b235e70dceace0ac2a.html", "dir_96c4b607d72bc8b235e70dceace0ac2a" ],
    [ "Gauge", "dir_80208035a125a085208ed38c691d4bd8.html", "dir_80208035a125a085208ed38c691d4bd8" ]
];