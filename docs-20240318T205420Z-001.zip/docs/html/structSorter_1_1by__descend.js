var structSorter_1_1by__descend =
[
    [ "operator()", "structSorter_1_1by__descend.html#ad37fa2b313d07d1271ac0dba52ae2a24", null ],
    [ "operator()", "structSorter_1_1by__descend.html#a76e04154dfd6085f1d602cee534b112d", null ],
    [ "operator()", "structSorter_1_1by__descend.html#a364e79fa915f89e6d18bf8324d7185a3", null ],
    [ "operator()", "structSorter_1_1by__descend.html#a2b4243a30349b28ec435cd452daff6c3", null ]
];