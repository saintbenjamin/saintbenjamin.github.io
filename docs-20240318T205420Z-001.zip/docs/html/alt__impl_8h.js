var alt__impl_8h =
[
    [ "Impl", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391", [
      [ "CORELIB", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a79ee2db604defbf1a228b02450137ba9", null ],
      [ "SIMD", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391aec3e9727bbc5c1073d8dc6fea807783a", null ],
      [ "SIMD2", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a90f2545bda75c5d31f1f65b3d8b7f275", null ],
      [ "VECTOR", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a1a85ef13eaa80e8561743892f9dba958", null ],
      [ "QXS", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391aa9a84ec502f3fb0c968bddf54b390003", null ],
      [ "ACCEL", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a11db0c836ba3cf1c58641fc109ffe566", null ],
      [ "OPENACC", "alt__impl_8h.html#a53792440f7baa1a1276e6521b526b391a6ee90253bddf7d833c52893e037a869f", null ]
    ] ],
    [ "alignment_size", "alt__impl_8h.html#a74644fe924354a27594d7bd4168e07ac", null ]
];