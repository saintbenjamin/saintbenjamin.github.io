var test__Gauge__Plaquette_8cpp =
[
    [ "plaquette", "test__Gauge__Plaquette_8cpp.html#a73724b4e308271f1a4a7d46445f5da2c", null ],
    [ "plaquette_eo", "test__Gauge__Plaquette_8cpp.html#a5cdc481ef9921bc9a675f3ab46e5d156", null ],
    [ "plaquette_lex", "test__Gauge__Plaquette_8cpp.html#a1986970962876b9d29dd936a208fcb08", null ]
];