var afopr__Wilson__Chemical_8h =
[
    [ "AFopr_Wilson_Chemical< AFIELD >", "classAFopr__Wilson__Chemical.html", "classAFopr__Wilson__Chemical" ]
];